package bono;

import java.util.ArrayList;
import java.util.Arrays;

public class GraphExplorationCourses {
	
	//Input data
	private int cota;
	private int [] daysC;
	private int [] people;
	private  ArrayList<int[][]> relations;
	private int [] optD;
	

}

class CourseState{
	int[] days;
	
	public CourseState(int[] days) {
		this.days = Arrays.copyOf(days, days.length);
	}
	
	public int getNumberCourses() {
		return days.length;
	}
}